Está é uma simulação de elevador produzida pelo grupo 3 da turma 33Q do curso de Engenharia de Computação na aula de Tópicos Especiais, sob mentoria do professor Luís Fernando Teixeira Bicalho e dos monitores Leonardo Trote Martins e Marcello Braga Nascif Filho

Grupo 3:
Eduardo Brandão de Freitas
João Pedro Covello Valente
Luís Felipe da Silva Seibel

-Para mudar o trajeto do elevador altere os pedidos dentro do arquivo pedidos.txt (0 corresponde ao térreo)
-Pressionando a tecla R a simulação é reiniciada
-Pressionando a tecla Esc a simulação é encerrada
-NÃO pressione a tecla W à menos que se sinta pronto para ver o que é oculto